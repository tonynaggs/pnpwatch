readme.txt file for PnPwatch 1.2

Description:
PnPwatch shows Plug'n'Play events in Windows 95 or NT
(Only tested with Windows 95)

Important:
The user assumes all responsibility for any problems
associated with or consequential to using this program.

All bug reports, etc to the author, email: amn@ubik.demon.co.uk

Files:
readme.txt      this file

PnPwatch.exe    compiled, ready to run version of the program!

watch.c         main source file
watch.rc        resource template
resource.h      resource header file
pnp.ico         large icon
pnpsm.ico       small icon
pnpwatch.mak    MakeFile for Microsoft Visual C 4.2

Compilation:
Developed with Microsoft Visual C 4.2.  It should compile with any C
compiler that targets Microsoft Windows 32-bit applications, (eg Watcom,
Borland or Symantec).  You will need to create an appropriate makefile 
for your compiler to build a Win32 SDK (ie non-MFC) Windows application.

Copyright (c) 1997, 1998 Anthony Naggs
See comments in watch.c for some distribution restrictions.  In general,
PnPwatch.exe may be distributed unmodified, the source files may be used
for informational purposes.  Neither the executable nor the source code
may be represented as the work of any other person, or used as the major
portion of a commercial product.  If in doubt contact the author for
permission.

Description:
  Utility for watching Windows 95 or NT Plug'n'Play events, eg the arrival
  or removal of CD-ROMs or PCMCIA cards.  This is FREE software, no user 
  should believe they have paid to use this software!
  Clarification: (1) the cost of media may be charged for; or (2) it may
  be included in CD-ROM collections of Freeware and trial versions of
  Shareware software.
