/* 
PnPwatch version 1.1

Simple program to report all Windows 95 Plug'n'Play event broadcasts
 
Copyright (c) 1997 Anthony Naggs

Email: amn@ubik.demon.co.uk
 
Copyright Assignment of Rights:
    The executable copy of this program may by used ("run") without charge
by any person.  This program is intended to run as an application for 
Microsoft Windows 95.  The user assumes all responsibility for any problems
associated with or consequential to using this program.

    The source code is provided as a courtesy to anyone interested.

	The program may be adapted or modified for non-commercial purposes, so
long as reference to the original author and copyright assignments are retained.

    It may also be adapted or included with a commercial product if;
(1) it retains the original author's comments and copyright, and
(2) it comprises a minor portion of the total product.

    Specific requests for permission to distribute may be addressed to the
author.
*/


#include <windows.h>

#include <dbt.h>				/* PnP definitions */


#include <string.h>
#include <stdio.h>


/* my stuff */
#include "resource.h"



#define PRG_NAME	"PnP Watch"


/* lots of string buffer space (!) */
static	char	NewText[8192];
static	char	VolName[256];	



#define	WM_INITMAIN		(WM_USER+107)


/* a few globals */
static	char const	szAppName[] = PRG_NAME;
static	HINSTANCE	hInstanceGlobal;
static	HWND		hWndMain, hWndLB;




/* local functions */
ATOM	RegisterMainWindow (HINSTANCE hInstance);
HWND	CreateMainDialog (HINSTANCE hInstance);
void	OnDeviceChange (HWND hDlg, UINT uiType, LPARAM lParam);
void	DescribeDevice (DEV_BROADCAST_HDR *pdbt, UINT uiType);
void	PrintDeviceNode (unsigned long DevNode);

BOOL CALLBACK	MainDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK	AboutDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);



/* real code begins here ... */

int WINAPI WinMain (
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	PSTR szCmdLine,
	int iCmdShow
)
{
	//HWND		hWnd;
	MSG			msg;
	ATOM		ClassId;

	/*** Minimal Initialisation ***/
	hInstanceGlobal = hInstance;

	ClassId = RegisterMainWindow (hInstance);


	/*** Ready to Paint ! ***/

	hWndMain = CreateDialog (hInstance, MAKEINTRESOURCE(IDD_MAIN), 0, MainDlgProc);


	/* now we have the information to initialise the window */
	ShowWindow (hWndMain, iCmdShow);

	/* allow dialog box to initialise! */
	PostMessage (hWndMain, WM_INITMAIN, 0, 0);


	while (GetMessage (&msg, NULL, 0, 0)) {
		/* remember to process dialog box stuff */
		if (IsDialogMessage (hWndMain, &msg)) 
			continue;
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}	/* WinMain() */




ATOM	RegisterMainWindow (HINSTANCE hInstance)
{
	WNDCLASSEX	WndClass;

	WndClass.cbSize			= sizeof (WndClass);
	WndClass.style			= CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc	= DefDlgProc;		//MainWndProc;
	WndClass.cbClsExtra		= 0;
	WndClass.cbWndExtra		= DLGWINDOWEXTRA;
	WndClass.hInstance		= hInstance;
	WndClass.hIcon			= LoadIcon (hInstance, MAKEINTRESOURCE(IDI_PNP));
	WndClass.hCursor		= LoadCursor (NULL, IDC_ARROW);
	WndClass.hbrBackground	= GetStockObject (LTGRAY_BRUSH);
	WndClass.lpszMenuName	= NULL;
	WndClass.lpszClassName	= "PnPwatch";
	WndClass.hIconSm		= LoadIcon (hInstance, MAKEINTRESOURCE(IDI_PNPSM));

	return RegisterClassEx (&WndClass);
}	/* RegisterDnaMainWindow() */



BOOL CALLBACK MainDlgProc (
	HWND hWnd,
	UINT iMsg,
	WPARAM wParam,
	LPARAM lParam
)
{
	/* a couple of statics */
	static unsigned	hTimer = 0;
	static unsigned	NewEvent = 0;

	/* other locals */
	int			ReturnNill = 0;
	WORD		Cmd;



	switch (iMsg) {
	case WM_INITMAIN:	/* my special message to init dialog box! */

		hWndLB = GetDlgItem (hWnd, IDC_PNPEVENTS);

		ReturnNill++;
		break;

	case WM_INITDIALOG:	/* from CreateDialog() */
		// return TRUE  unless you set the focus to a control
		SetFocus (GetDlgItem (hWnd, IDC_PNPEVENTS));
		return 0;

	case WM_DESTROY:
		if (0 != hTimer) {
			KillTimer (hWnd, hTimer);
			hTimer = 0;
		}
		PostQuitMessage (0);
		ReturnNill++;
		break;

	case WM_DEVICECHANGE:
		OnDeviceChange (hWnd, (UINT) wParam, lParam);
		NewEvent++;
		if (0 == hTimer) {
			SetTimer (hWnd, hTimer = 67, 500, NULL);
		}
		return (TRUE);

	case WM_TIMER:
		if (NewEvent > 0) {
			/* Brute Force: persuade ListBox that 'End' key has been pressed */
			/* (LBSETTOPINDEX sets top most visible item, but we don't know the number of visible rows!) */
			SendMessage (hWndLB, WM_KEYDOWN, VK_END, 0);
			SendMessage (hWndLB, WM_KEYUP, VK_END, 0xC0000000);
			NewEvent = 0;
		}
		break;

	case WM_COMMAND:
		Cmd = LOWORD (wParam);

		switch (Cmd) {
		case IDC_MINIMIZE:
			/* we use SW_MINIMIZE which also deactivates the window,
				whereas SW_SHOWMINIMIZED leaves the window activated */
			ShowWindow (hWnd, SW_MINIMIZE);
			break;

		case IDC_CLEAR:
			EnableWindow (GetDlgItem(hWnd, IDC_CLEAR), FALSE);
			SendMessage (hWndLB, LB_RESETCONTENT, 0, 0);
			break;

		case IDC_ABOUT:
			DialogBox (hInstanceGlobal, MAKEINTRESOURCE(IDD_ABOUT), hWnd, AboutDlgProc);
			ReturnNill++;
			break;

		case IDC_EXIT:
			SendMessage (hWnd, WM_CLOSE, 0, 0l);
			ReturnNill++;
			break;
		}
		break;

	case WM_CLOSE:
		DestroyWindow (hWnd);
		ReturnNill++;
		break;
	}

	
	if (ReturnNill)
		return 1;		// handled here
	else
		return 0;		// default handling
}	/* MainDlgProc() */



BOOL CALLBACK AboutDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	/* IDD_DNAABOUT */

	switch (iMsg) {
	case WM_COMMAND: 
		switch (LOWORD(wParam)) {
		case IDOK :
			EndDialog (hDlg, 0);
			/* handled message */
			return 1;
		}
		break;
	}

	return 0;
}	/* AboutDlgProc() */




void	OnDeviceChange (HWND hDlg, UINT uiType, LPARAM lParam)
{
/*
 * Broadcast message and receipient flags.
 *
 * Note that there is a third "flag". If the wParam has:
 *
 * bit 15 on:	lparam is a pointer and bit 14 is meaningfull.
 * bit 15 off:	lparam is just a UNLONG data type.
 *
 * bit 14 on:	lparam is a pointer to an ASCIIZ string.
 * bit 14 off:	lparam is a pointer to a binary struture starting with
 *		a dword describing the length of the structure.
 */
	SYSTEMTIME	SysTime;
	ULONG	ulParam = 0l;
	char	*lpStrParam = NULL;
	void	*lpStruct = NULL;
	int		res;


	NewText[0] = 0;

	GetLocalTime (&SysTime);

	sprintf (NewText, "%2u/%02u %2u:%02u:%02u  ",
		SysTime.wDay, SysTime.wMonth, SysTime.wHour, SysTime.wMinute, SysTime.wSecond);

	if (uiType & 0x8000) {
		if (uiType & 0x4000) {
			lpStrParam = (char *) lParam;
			sprintf (NewText + strlen(NewText), "StrParam = \042%s\042, ", lpStrParam);
		} else {
			lpStruct = (void *) lParam;
			DescribeDevice ((DEV_BROADCAST_HDR *) lpStruct, uiType);
		}
	} else {
		ulParam = (ULONG) lParam;
		if (ulParam != 0)
			sprintf (NewText + strlen(NewText), "ulParam = 0x%08lX, ", ulParam);
	}


	switch (uiType) {
	case DBT_CONFIGCHANGECANCELED:
		/* (lParam = 0) */
		strcat (NewText, "Change Canceled");
		break;

	case DBT_CONFIGCHANGED:
		/* (lParam = 0) */
		strcat (NewText, "Config has Changed");
		break;

	case DBT_DEVICEARRIVAL:
		/* (lParam = DEV_BROADCAST_HDR *) */
		strcat (NewText, "Arrived");
		break;

	case DBT_DEVICEQUERYREMOVE:
		/* (lParam = DEV_BROADCAST_HDR *) */
		strcat (NewText, "Query Remove");
		break;

	case DBT_DEVICEQUERYREMOVEFAILED:
		/* (lParam = DEV_BROADCAST_HDR *) */
		strcat (NewText, "Query Remove Failed");
		break;

	case DBT_DEVICEREMOVECOMPLETE:
		/* (lParam = DEV_BROADCAST_HDR *) */
		strcat (NewText, "Removal Complete");
		break;

	case DBT_DEVICEREMOVEPENDING:
		/* (lParam = DEV_BROADCAST_HDR *) */
		strcat (NewText, "Remove Pending");
		break;

	case DBT_DEVICETYPESPECIFIC:
		/* (lParam = 0 or DEV_BROADCAST_HDR *) */
		strcat (NewText, "'Type Specific' PnP event");
		break;

	case DBT_QUERYCHANGECONFIG:
		/* (lParam = 0) */
		strcat (NewText, "Query Change Config");
		break;

	case DBT_USERDEFINED:
		strcat (NewText, "User Defined PnP event");
		break;

	case DBT_DEVNODES_CHANGED:
		/* (lParam = 0) */
		strcat (NewText, "One or more Devnodes have changed");
		break;

	case DBT_MONITORCHANGE:
		strcat (NewText, "Monitor Change");
		break;

	default:
		sprintf (NewText+strlen(NewText), "Unknown PnP event 0x%08lX", uiType);
		break;
	}

	res = SendMessage (hWndLB, LB_ADDSTRING, 0, (LPARAM) NewText);

	if (res == 0) {
		/* first item in LB (res is item number *NOT* simple success/fail) */
		EnableWindow (GetDlgItem (hDlg, IDC_CLEAR), TRUE);
	} else if (res < 0) {
		/* negative res is an error */
		MessageBox (hDlg, "Event list overflow!", PRG_NAME, MB_OK);
	}

	return;
}	/* OnDeviceChange () */


void	DescribeDevice (DEV_BROADCAST_HDR *pdbt, UINT uiType)
{
	char	*desc = 0;


	if (uiType == DBT_USERDEFINED) {
		struct _DEV_BROADCAST_USERDEFINED	*pdbud = (struct _DEV_BROADCAST_USERDEFINED *) pdbt;

		sprintf (NewText + strlen(NewText), "%.*s",
			(pdbud->dbud_dbh.dbch_size - sizeof(DEV_BROADCAST_HDR) - 1), pdbud->dbud_szName);
	} else {
		switch (pdbt->dbch_devicetype) {
		case DBT_DEVTYP_DEVNODE:
			{
				DEV_BROADCAST_DEVNODE	*pdbcd = (DEV_BROADCAST_DEVNODE *) pdbt;

				strcat (NewText, "Device Node ");
				PrintDeviceNode ((unsigned long) pdbcd->dbcd_devnode);
				/* description already in NewText, desc left as 0 */
			}
			break;

		case DBT_DEVTYP_VOLUME:
			{
				unsigned				drive, drvCount;
				DEV_BROADCAST_VOLUME	*pdbcv = (DEV_BROADCAST_VOLUME *) pdbt;
				unsigned long			drvMask = pdbcv->dbcv_unitmask;

				if (pdbcv->dbcv_flags & DBTF_MEDIA)
					desc = "Disk in ";
				else if ( 0 == (pdbcv->dbcv_flags & DBTF_NET))
					desc = "Physical ";

				if (pdbcv->dbcv_flags & DBTF_NET)
					desc = "Network ";
				
				sprintf (NewText + strlen(NewText), "%sDrive ", (desc) ? desc : "");

				for (drive = 0, drvCount = 0; (drvMask) && (drive < 32); drive++)
					if (drvMask & (1 << drive)) {
						drvMask &= ~(1 << drive);
						sprintf (NewText+strlen(NewText), "%s%c:",
							(drvCount == 0) ? "" : " & ", 'A'+drive);
						drvCount++;
					}

				/* check for volume name! */
				if ((DBT_DEVICEARRIVAL == uiType) && (drvCount == 1)) {
					char	VolId[4] = "A:\\";
					// No missing disk error message
					UINT	ErrMode = SetErrorMode (SEM_FAILCRITICALERRORS);

					VolId[0] = 'A' + (drive - 1);
					if (TRUE == GetVolumeInformation (VolId,
							VolName, sizeof(VolName),		// volume name buffer
							NULL,			// volume serial number
							NULL,			// maximum component size
							NULL,			// filesystem flags
							NULL, 0)) {		// filesystem name buffer
						sprintf (NewText+strlen(NewText), " \042%s\042", VolName);
					}

					// restore error mode 
					SetErrorMode (ErrMode);
				}

				/* description already in NewText, desc left as 0 */
				desc = 0;
			}
			break;
		
		case DBT_DEVTYP_PORT:
			{
				DEV_BROADCAST_PORT	*pdbcp = (DEV_BROADCAST_PORT *) pdbt;

				if ((strnicmp (pdbcp->dbcp_name, "Communication port COM", 22) == 0) ||
						(strncmp (pdbcp->dbcp_name, "COM", 3) == 0) ||
						(NULL != strstr (pdbcp->dbcp_name, "Modem")) ||
						(NULL != strstr (pdbcp->dbcp_name, "modem")) )
					desc = "Serial Port";
				else if (strncmp (pdbcp->dbcp_name, "LPT", 3) == 0)
					desc = "Parallel Port";
				else
					desc = "Serial/Parallel Device";
				sprintf (NewText + strlen(NewText), "%s: %.*s", desc, 
					(pdbcp->dbcp_size - sizeof(DEV_BROADCAST_HDR) - 1), pdbcp->dbcp_name);

				/* description already in NewText, desc left as 0 */
				desc = 0;
			}
			break;

		case DBT_DEVTYP_NET:
			/* sets desc to point to simple description */
			{
				DEV_BROADCAST_NET	*pdbcn = (DEV_BROADCAST_NET *) pdbt;

				if (pdbcn->dbcn_flags & DBTF_XPORT)
					desc = "New Network Transport";
				else if (pdbcn->dbcn_flags & DBTF_SLOWNET)
					desc = "Network Transport is slow";
				else
					desc = "Network Resource";
			}
			break;

		case DBT_DEVTYP_OEM:
			{
				DEV_BROADCAST_OEM	*pdbco = (DEV_BROADCAST_OEM *) pdbt;

				sprintf (NewText + strlen(NewText), "OEM Device Id = 0x%08lX (SuppFunc = 0x%08lX) ", 
					(unsigned long) pdbco->dbco_identifier,
					(unsigned long) pdbco->dbco_suppfunc);
				/* description already in NewText, desc left as 0 */
			}
			break;

		default:
			sprintf (NewText + strlen(NewText), "Unknown Device Type 0x%08lx", (unsigned long) uiType);
			/* description already in NewText, desc left as 0 */
			break;
		}
	}

	if (desc) {
		strcat (NewText, desc);
	}

	strcat (NewText, ", ");

}	/* DescribeDevice() */



void	PrintDeviceNode (unsigned long DevNode)
{
	char	Keyname [256];
	HKEY	DevKey;
	DWORD	lKeyname;
		
	
	_snprintf (Keyname, sizeof(Keyname), "Config Manager\\Enum\\%8.8lX", DevNode);

	if (ERROR_SUCCESS == RegOpenKeyEx (HKEY_DYN_DATA, Keyname, 0, KEY_READ, &DevKey)) {
		lKeyname = sizeof(Keyname);
		RegQueryValueEx (DevKey, "HardWareKey", NULL, NULL, Keyname, &lKeyname);

		sprintf (NewText + strlen(NewText), "%s (%08lX)", Keyname, DevNode);

		RegCloseKey (DevKey);
	} else {
		sprintf (NewText + strlen(NewText), "0x%08lX", DevNode);
	}
}	/* PrintDevNode() */



/* End of file Watch.C */