//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by watch.rc
//
#define IDI_ICON1                       101
#define IDI_PNP                         101
#define IDD_ABOUT                       102
#define IDD_MAIN                        103
#define IDI_PNPSM                       106
#define IDC_EXIT                        1000
#define IDC_ABOUT                       1001
#define IDC_PNPEVENTS                   1002
#define IDC_CLEAR                       1003
#define IDC_MINIMIZE                    1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
